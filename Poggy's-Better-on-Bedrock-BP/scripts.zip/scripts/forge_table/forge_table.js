import {
  world,
  Items,
  ItemStack,
  Entity,
  ItemEnchantsComponent,
  ItemTypes,
  EntityInventoryComponent,
  Block,
  Enchantment,
  MinecraftEnchantmentTypes,
} from "@minecraft/server";
import { system } from "@minecraft/server";
import {
  MinecraftEntityTypes,
  DynamicPropertiesDefinition,
} from "@minecraft/server";
import {
  ActionFormData,
  MessageFormData,
  ModalFormData,
} from "@minecraft/server-ui";

world.events.itemUseOn.subscribe((use) => {
  let { source: player, item } = use;

  let blockTest = world
    .getDimension(player.dimension.id)
    .getBlock(use.getBlockLocation());
  if (
    item?.typeId == "minecraft:netherite_helmet" ||
    item?.typeId == "minecraft:netherite_chestplate" ||
    item?.typeId == "minecraft:netherite_leggings" ||
    (item?.typeId == "minecraft:netherite_boots" &&
      blockTest?.typeId == "better_on_bedrock:forge_table")
  ) {
    UI(player);
  } else if (
    item?.typeId != "minecraft:netherite_helmet" &&
    item?.typeId != "minecraft:netherite_chestplate" &&
    item?.typeId != "minecraft:netherite_leggings" &&
    (item?.typeId != "minecraft:netherite_boots" &&
      blockTest?.typeId == "better_on_bedrock:forge_table")
  ) {
    blockWarning(player);
  }
});
function blockWarning(player) {
  let form = new ActionFormData();
  form.title("No Armor?");
  form.body(
    "§cYou are unable to forge your gold into your Netherite Armor. To forge, hold the netherite armor in your hand and use the table again."
  );
    form.button("Ok");
     form.show(player).then((response) => {
    if (response.selection == 0) {

      }
    })
}


function UI(player) {
  let form = new ActionFormData();
  form.title("Forge Armor?");
  form.body(
    "You are about to forge your Netherite Armor to be Gilded.\n\nIn order to forge your armor you need at least 1 gold ingot."
  );
  ///buttons
  form.button("Forge");
  form.button("Don't Forge");
  form.show(player).then((response) => {
    if (response.selection == 0) {
      console.warn("Dust");
      let inv = player.getComponent("inventory").container;
      let item = inv.getItem(player.selectedSlot);
      const inventory = player.getComponent(
        EntityInventoryComponent.componentId
      );
      for (let slot = 0; slot < inventory.container.size; slot++) {
        const itemStack = inventory.container.getItem(slot);
        if (itemStack?.typeId === "minecraft:gold_ingot") {
          let container = player.getComponent("inventory").container;
          let oldItem = container?.getItem(player.selectedSlot);
          let newItem = new ItemStack(ItemTypes?.get("better_on_bedrock:netherite_helmet"));
          let newItem2 = new ItemStack(
            ItemTypes?.get("better_on_bedrock:netherite_chestplate")
          );
          let newItem3 = new ItemStack(
            ItemTypes?.get("better_on_bedrock:netherite_leggings")
          );
          let newItem4 = new ItemStack(ItemTypes?.get("better_on_bedrock:netherite_boots"));

          if (item?.typeId == "minecraft:netherite_helmet") {
            newItem.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments = oldItem.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments;
            container.setItem(player.selectedSlot, newItem);
            player.runCommandAsync("clear @p gold_ingot 0 1");
          }
          if (item?.typeId == "minecraft:netherite_chestplate") {
            newItem2.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments = oldItem.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments;
            container.setItem(player.selectedSlot, newItem2);
            player.runCommandAsync("clear @p gold_ingot 0 1");
          }
          if (item?.typeId == "minecraft:netherite_leggings") {
            newItem3.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments = oldItem.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments;
            container.setItem(player.selectedSlot, newItem3);

            player.runCommandAsync("clear @p gold_ingot 0 1");
          }
          if (item?.typeId == "minecraft:netherite_boots") {
            newItem4.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments = oldItem.getComponent(
              ItemEnchantsComponent.componentId
            ).enchantments;
            container.setItem(player.selectedSlot, newItem4);
            player.runCommandAsync("clear @p gold_ingot 0 1");
          }
        }
      }
    }
    if (response.selection == 1) {
      console.warn("Spare");
    }
  });
}
