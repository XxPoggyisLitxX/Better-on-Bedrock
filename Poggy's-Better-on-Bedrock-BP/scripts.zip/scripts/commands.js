import { world,  Items, ItemStack, MinecraftEntityTypes, DynamicPropertiesDefinition, MinecraftBlockTypes, BlockType, ScreenDisplay, ItemTypes } from "@minecraft/server"
import "./hardcore_ui/hardcore_selection_screen.js"

world.events.worldInitialize.subscribe((eventData) => {
  let playerCompShowTick = new DynamicPropertiesDefinition()
  playerCompShowTick.defineNumber("uses")

  eventData.propertyRegistry.registerEntityTypeDynamicProperties(playerCompShowTick, MinecraftEntityTypes["player"])
})
world.events.playerSpawn.subscribe(ev => {
  console.warn("Player Loaded")
  console.warn(player.getDynamicProperty("uses"))
  let players = world.getPlayers()
  for (let player of players) {
    if(player.getDynamicProperty("uses") === undefined){
  player.setDynamicProperty("uses", 0)
  }}
})

var uses = 0
world.events.beforeChat.subscribe((chatEvent) => {
  let message = chatEvent.message.toLowerCase();
  if (message.startsWith("!")) {
    chatEvent.cancel = true;
    switch (message) {
      //help list

      case "!block_info":
        chatEvent.sender.tell('§eGet info about a selected block. §cSyntax:"!block_info miners_bench", "!block_info forge_table", "!block_info waystone".')
      break;
      case "!block_info miners_bench":
        console.warn(chatEvent.sender.getDynamicProperty("uses"))
        chatEvent.sender.tell('§3To use this block, you need to first craft your axe/pickaxe. When you crafted your tool, you need to hold either the axe or pickaxe when interacting §e(L2/LT/TAP/right-click)§3 with the block. When you interacted with the block, it will open a UI with instructions for you to follow.\n§cYou need to craft the axe/pickaxe to get the enchantments.')
      break;
      case "!block_info forge_table":
        console.warn(chatEvent.sender.getDynamicProperty("uses"))
        chatEvent.sender.tell('§3To use this block, you need to hold any Netherite Armor piece. When you interact §e(L2/LT/TAP/right-click)§3 with the block, a UI will open with instructions to follow.')
      break;
      case "!block_info waystone":
        console.warn(chatEvent.sender.getDynamicProperty("uses"))
        chatEvent.sender.tell('§3To use this block, you need a Overworld Waystone Key. Hold the key and interact §e(L2/LT/TAP/right-click)§3 on the block. This will open a UI with instructions to follow.')
      break;

      case "!contributors":
        chatEvent.sender.runCommandAsync(
          `tellraw @s{"rawtext":[{"text": "§eContributors:\n§aLegend\n§aCreepager15\n§aHachuden\n§aSumi (Yanna :3)\n§aPan (i,love.pandas)\n§aXorkent\n§aCiosciaa\n§aHerobrine64\n§aElektrika\n§aJayly"}]}`
        );
        break;

        case "!difficulty":
          chatEvent.sender.tell('§eSet your difficulty. §cSyntax:"!difficulty normal", "!difficulty hardcore"')
        break;
        case "!difficulty normal":
          if (chatEvent.sender.getDynamicProperty("uses") < 3){
            chatEvent.sender.setDynamicProperty("uses", uses += 1)
            chatEvent.sender.removeTag("selected")
            chatEvent.sender.addTag("selected2")
            chatEvent.sender.tell('§aSet Better on Bedrock difficulty to recommended difficulty (Normal Mode).')
            chatEvent.sender.removeTag("hardcoreDeath")
           } else if (chatEvent.sender.getDynamicProperty("uses") >= 3) {
            chatEvent.sender.tell("§cYou already changed your difficulty 3 times. Max uses: 3/3.")
           }
            break;
          case "!difficulty hardcore":
             if (chatEvent.sender.getDynamicProperty("uses") < 3){
              chatEvent.sender.setDynamicProperty("uses", uses += 1)
            chatEvent.sender.removeTag("selected2")
            chatEvent.sender.addTag("selected")
            chatEvent.sender.tell('§aSet Better on Bedrock difficulty to Hardcore Mode.')
          } else if (chatEvent.sender.getDynamicProperty("uses") >= 3) {
            chatEvent.sender.tell("§cYou already changed your difficulty 3 times. Max uses: 3/3.")
           }
          break;
        case "!help":
          console.warn(chatEvent.sender.getDynamicProperty("uses"))
          chatEvent.sender.tell("§e!contributors: §aShows all the people that contributed.\n§e!difficulty: §aAllows to change difficulty only 3 times a world.\n§e!block_info: §aGives a detailed description on the use of selected blocks.")
        break;
    }
  }
});
