import { world, Items, ItemStack, Entity, ItemEnchantsComponent, ItemTypes, EntityInventoryComponent, Block, Enchantment, MinecraftEnchantmentTypes } from "@minecraft/server"
import { system, Vector } from "@minecraft/server";
import { MinecraftEntityTypes, DynamicPropertiesDefinition } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"

world.events.worldInitialize.subscribe((eventData) => {
  let playerCompShowTick = new DynamicPropertiesDefinition()
  playerCompShowTick.defineBoolean("hardcoreDeath")
  playerCompShowTick.defineBoolean("hardcoreOption")
  playerCompShowTick.defineBoolean("joined")
  eventData.propertyRegistry.registerEntityTypeDynamicProperties(playerCompShowTick, MinecraftEntityTypes["player"])
})

system.events.beforeWatchdogTerminate.subscribe(data => {
  data.cancel = true;
});
      const DimensionNames = {
        ["minecraft:overworld"]: "Overworld",
        ["minecraft:nether"]: "Nether",
        ["minecraft:the_end"]: "End"
      };

      ///
     export function onPlayerDeath() {
          let players = world.getPlayers()
          for (let player of players) {
            let playerHealt = player.getComponent("minecraft:health").current
            let isDeath = player.hasTag("death")
            let Dimension = world.getDimension(player.dimension.id)
            if (playerHealt == 0 && isDeath == false) {
              const dName = DimensionNames[player.dimension.id];
              player.addTag("death")
              let entity = Dimension.spawnEntity("better_on_bedrock:player_corpse", new Vector(player.location.x, player.location.y, player.location.z));
              entity.nameTag = "Corpse of " + player.name;
              player.runCommandAsync(`tellraw @s{"rawtext":[{"text": "§a${player.nameTag} §rdied at: §l§e${Math.round(player.location.x)}, ${Math.round(player.location.y)}, ${Math.round(player.location.z)},§r§f in The §a${dName}"}]}`)
              player.addTag("lol")
            } else if (playerHealt > 0) {
              player.removeTag("death")
            } else if(playerHealt == 0 && player.hasTag("selected") == true) {
              player.addTag("hardcoreDeath")
              
            } if(playerHealt == 20 && player.hasTag("hardcoreDeath") == true) {
              player.runCommandAsync("function hardcore")
            }
        }
        }
      
      
        //system.runSchedule(onPlayerDeath)
        world.events.entityHit.subscribe(data => {
          let { entity, hitEntity } = data;
      if(data.hitEntity?.typeId == 'better_on_bedrock:player_corpse'){
        console.warn("lol");
        bounty_tier_page(entity, hitEntity)
          }})
      
          function bounty_tier_page(entity, hitEntity) {
            let form = new ActionFormData()
              form.title("Are You Sure?")
              form.body("You are about to turn your corpse into ashes.\n\nIf you decide to turn your corpse into ash, all stored items will be lost.")
              ///buttons
              form.button("Dust")
              form.button("Spare")
              form.show(entity).then((response) => {
                if (response.selection == 0) {
                  console.warn("Dust")
                  hitEntity.triggerEvent('entity_transform')
                  //world.getDimension('overworld').runCommandAsync('tag @e[type=better_on_bedrock:player_corpse] add dusted')
                }
                if (response.selection == 1) {
                  console.warn("Spare")
                }
              })
          }
          
              //We use this to complete bounties where we obtain items and other stuff, aswell as entity kills and block placements.

    let itemed;
function saveItem(itemStack) {
 if(!itemed) {
  itemed = itemStack;return true;
  } else return false;
};

    world.events.itemReleaseCharge.subscribe(data => {

      let players = world.getPlayers()
      for (let player of players) {
      let inv = player.getComponent( 'inventory' ).container
      let item = inv.getItem( player.selectedSlot )
      const itemStack = inv.getItem(player.selectedSlot);
      if (itemStack?.typeId === 'runecraft:wooden_spear') {
  
      var container = player.getComponent('inventory').container
      var oldItem = container?.getItem(player.selectedSlot) 
      player.removeTag("wooden_spear")
      }

      if (itemStack?.typeId === 'better_on_bedrock:iron_spear') {
  
        var container = player.getComponent('inventory').container
        var newItem =  new ItemStack(ItemTypes?.get("better_on_bedrock:iron_spear"));
        var oldItem = container?.getItem(player.selectedSlot) 
        player.removeTag("iron_spear")
        }
        if (itemStack?.typeId === 'better_on_bedrock:golden_spear') {
  
          var container = player.getComponent('inventory').container
          var newItem =  new ItemStack(ItemTypes?.get("better_on_bedrock:golden_spear"));
          var oldItem = container?.getItem(player.selectedSlot) 
          player.removeTag("golden_spear")
          }
          if (itemStack?.typeId === 'better_on_bedrock:diamond_spear') {
  
          var container = player.getComponent('inventory').container
          var newItem =  new ItemStack(ItemTypes?.get("better_on_bedrock:diamond_spear"));
          var oldItem = container?.getItem(player.selectedSlot) 
          player.removeTag("diamond_spear")
          }
      let e = system.runInterval(data => {
      /*if(player.hasTag("wooden_spear") && itemStack?.typeId === 'runecraft:wooden_spear' && itemStack?.getComponent("durability").damage <= 25) {
        console.warn(itemStack?.getComponent("durability").damage)
        player.removeTag("wooden_spear")
        itemToSave.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        container.setItem(player.selectedSlot, newItem);
        if(!player.hasTag("wooden_spear")){
        world.events.tick.unsubscribe(e);
      }}*/
      if(itemed?.typeId == "runecraft:wooden_spear" && player?.hasTag("wooden_spear") && itemStack?.getComponent("durability").damage <= 25) {
        //itemed.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        itemed.getComponent("durability").damage = oldItem.getComponent("durability").damage += 1;
        container.addItem( itemed);
       }
      if(player.hasTag("iron_spear") && itemStack?.typeId === 'better_on_bedrock:iron_spear' && itemStack?.getComponent("durability").damage <= 125) {
        console.warn(itemStack?.getComponent("durability").damage)
        player.removeTag("iron_spear")
        newItem.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        container.addItem( newItem);
        if(!player.hasTag("iron_spear")){
        world.events.tick.unsubscribe(e);
      }}
      if(player.hasTag("golden_spear") && itemStack?.typeId === 'better_on_bedrock:golden_spear' && itemStack?.getComponent("durability").damage <= 125) {
        console.warn(itemStack?.getComponent("durability").damage)
        player.removeTag("golden_spear")
        newItem.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        container.addItem(newItem);
        if(!player.hasTag("golden_spear")){
        world.events.tick.unsubscribe(e);
      }}
      if(player.hasTag("diamond_spear") && itemStack?.typeId === 'better_on_bedrock:diamond_spear' && itemStack?.getComponent("durability").damage <= 125) {
        console.warn(itemStack?.getComponent("durability").damage)
        player.removeTag("diamond_spear")
        newItem.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        container.addItem( newItem);
        if(!player.hasTag("diamond_spear")){
        system.clearRun(e);
      }}
    }
    )}
    })
  