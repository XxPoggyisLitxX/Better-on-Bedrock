import { world, Items, ItemStack, Entity, ItemEnchantsComponent, Vector,  ItemTypes, EntityInventoryComponent, Block, Enchantment, MinecraftEnchantmentTypes } from "@minecraft/server"
import { system } from "@minecraft/server";
import { MinecraftEntityTypes, DynamicPropertiesDefinition } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"
import { getPlayerExperienceLevel } from 'get_level_tests'

world.events.itemUseOn.subscribe((use) => {
  let player = use.source,
    item = use.item;
  let blockTest = world
    .getDimension(player.dimension.id)
    .getBlock(use.getBlockLocation());
  if (
    (item?.typeId == "pog:stone_pickaxe") |
      (item?.typeId == "pog:iron_pickaxe") |
      (item?.typeId == "pog:diamond_pickaxe") |
      (item?.typeId == "better_on_bedrock:stardust_pickaxe") |
      (item?.typeId == "better_on_bedrock:copper_pickaxe") |
      (item?.typeId == "pog:netherite_pickaxe") &&
    blockTest?.typeId == "better_on_bedrock:enchant_bench"
  ) {
    veinMine(player);
  }
});

function veinMine(player) {
  let level = player.runCommandAsync("xp 0 @s")
  let form = new ActionFormData();
  form.title("Enchant Pickaxe?");
  form.body(
    "§cTo enchant this pickaxe with Vein Miner I, you need at least §e6 experience levels §cand §e1 Vein Miner I Enchanted Book\n\n§aWhen you have both of the requirements, you'll be able to enchant.\n\n§3When you don't have the requirements, you won't be able to enchant your pickaxe."
  );
  ///buttons
  form.button("Enchant");
  form.button("Don't Enchant");
  form.show(player).then((response) => {
    if (response.selection == 0 && getPlayerExperienceLevel(player) >= 6) {
      console.warn(level);
      const inventory = player.getComponent(
        EntityInventoryComponent.componentId
      );
      for (let slot = 0; slot < inventory.container.size; slot++) {
        const itemStack = inventory.container.getItem(slot);
        if (itemStack?.typeId === "better_on_bedrock:vein_miner_book") {
          let inv = player.getComponent("inventory").container;
          let item = inv.getItem(player.selectedSlot);
          if (item?.typeId == "pog:stone_pickaxe") {
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p efficiency 1");
          }
          if (item?.typeId == "better_on_bedrock:stardust_pickaxe") {
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p efficiency 1");
          }
          if (item?.typeId == "better_on_bedrock:copper_pickaxe") {
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p efficiency 1");
          }
          if (item?.typeId == "pog:iron_pickaxe") {
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p unbreaking 1");
          }
          if (item?.typeId == "pog:diamond_pickaxe") {
            console.warn("dusted")
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p unbreaking 1");
          }
          if (item?.typeId == "pog:netherite_pickaxe") {
            item?.setLore(["§r§7Vein Miner I"]);
            player.runCommandAsync("clear @p better_on_bedrock:vein_miner_book 0 1");
            player.runCommandAsync("xp -6l @p");
            inv.setItem(player.selectedSlot, item);

            player.runCommandAsync("enchant @p unbreaking 1");
          }
        }
      }
    } else if (response.selection == 0 && getPlayerExperienceLevel(player) < 6) {
      player.tell("§cYou don't have enough levels.")
    }
    if (response.selection == 1) {
      console.warn("Spare");
    }
  });
}

async function r(block, done, starting) {
 


  for (const player of world.getPlayers()){
    const {dimension, location} = block
    
  const id = `${block.x} ${block.y} ${block.z}`;
  if (done.has(id)) {
    return;
  }
  done.add(id);
  if (
    starting ||
    block?.typeId == "better_on_bedrock:stardust_ore" ||
    block?.typeId == "better_on_bedrock:deepslate_stardust_ore" ||
    block?.typeId == "minecraft:deepslate_lapis_ore" ||
    block?.typeId == "minecraft:deepslate_redstone_ore" ||
    block?.typeId == "minecraft:deepslate_gold_ore" ||
    block?.typeId == "minecraft:deepslate_emerald_ore" ||
    block?.typeId == "minecraft:deepslate_iron_ore" ||
    block?.typeId == "better_on_bedrock:tin_ore" ||
    block?.typeId == "better_on_bedrock:alluminum_ore" ||
    block.hasTag("wood_pick_diggable") ||
    block.hasTag("stone_pick_diggable") ||
    block.hasTag("iron_pick_diggable") ||
    block.hasTag("diamond_pick_diggable") ||
    block.hasTag("gold_pick_diggable")
  ) {///better_on_bedrock:tin_ore
    await null;
      let inv = player.getComponent("inventory").container;
      let item = inv.getItem(player.selectedSlot);
      let lore = item.getLore();
      if (lore.includes("§r§7Vein Miner I")) {
        item.getComponent("durability").damage =
          item.getComponent("durability").damage +
          Math.floor(Math.random(0) * 0) +
          1;

        item.setLore(["§r§7Vein Miner I"]);
        inv.setItem(player.selectedSlot, item);
      }
      (async (res) => {
        res(
          block.dimension.runCommandAsync(
            `setblock ${block.x} ${block.y} ${block.z} air 0 destroy`
          )
        );
      })();
      r(dimension.getBlock(Vector.add(location, new Vector(1, 0, 0))), done)
      r(dimension.getBlock(Vector.add(location, new Vector(-1, 0, 0))), done)
      r(dimension.getBlock(Vector.add(location, new Vector(0, 1, 0))), done)
      r(dimension.getBlock(Vector.add(location, new Vector(0, -1, 0))), done)
      r(dimension.getBlock(Vector.add(location, new Vector(0, 0, 1))), done)
      r(dimension.getBlock(Vector.add(location, new Vector(0, 0, -1))), done)

      /*r(block.dimension.getBlock(block.location.offset(-1, 0, 0)), done);
      r(block.dimension.getBlock(block.location.offset(0, 1, 0)), done);
      r(block.dimension.getBlock(block.location.offset(0, -1, 0)), done);
      r(block.dimension.getBlock(block.location.offset(0, 0, 1)), done);
      r(block.dimension.getBlock(block.location.offset(0, 0, -1)), done);*/
  }
}}

world.events.blockBreak.subscribe(
  ({ block, player, brokenBlockPermutation }) => {
    let inv = player.getComponent("inventory").container;
    let item = inv.getItem(player.selectedSlot);
    if (
      brokenBlockPermutation.type.id == "better_on_bedrock:stardust_ore" ||
      brokenBlockPermutation.type.id == "better_on_bedrock:deepslate_stardust_ore" ||
      brokenBlockPermutation.type.id == "minecraft:coal_ore" ||
      brokenBlockPermutation.type.id == "minecraft:iron_ore" ||
      brokenBlockPermutation.type.id == "minecraft:copper_ore" ||
      brokenBlockPermutation.type.id == "minecraft:gold_ore" ||
      brokenBlockPermutation.type.id == "minecraft:redstone_ore" ||
      brokenBlockPermutation.type.id == "minecraft:diamond_ore" ||
      brokenBlockPermutation.type.id == "better_on_bedrock:tin_ore" ||
      brokenBlockPermutation.type.id == "better_on_bedrock:alluminum_ore" ||
      brokenBlockPermutation.type.id == "minecraft:lapis_ore" ||
      brokenBlockPermutation.type.id == "minecraft:deepslate_lapis_ore" ||
      brokenBlockPermutation.type.id == "minecraft:deepslate_copper_ore" ||
      brokenBlockPermutation.type.id == "minecraft:deepslate_iron_ore" ||
      brokenBlockPermutation.type.id == "minecraft:deepslate_redstone_ore" ||
      brokenBlockPermutation.type.id == "minecraft:deepslate_gold_ore"
    ) {
      if (
        item?.typeId == "minecraft:wooden_pickaxe" ||
        item?.typeId == "pog:stone_pickaxe" ||
        item?.typeId == "better_on_bedrock:stardust_pickaxe" ||
        item?.typeId == "better_on_bedrock:copper_pickaxe" ||
        item?.typeId == "pog:iron_pickaxe" ||
        item?.typeId == "minecraft:gold_pickaxe" ||
        item?.typeId == "pog:diamond_pickaxe" ||
        item?.typeId == "pog:netherite_pickaxe"
      ) {
        let players = world.getPlayers();
          let inv = player.getComponent("inventory").container;
          let item = inv.getItem(player.selectedSlot);
          let lore = item.getLore();
          if (lore.includes("§r§7Vein Miner I")) {
            if (
              item.getComponent("durability").damage <
              item.getComponent("durability").maxDurability
            ) {
              r(block, new Set(), true);
            }
          }
      }
    }
  }
);