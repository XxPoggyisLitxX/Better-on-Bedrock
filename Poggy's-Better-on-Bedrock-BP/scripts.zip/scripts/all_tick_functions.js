import { world, Items, ItemStack, Entity, ItemEnchantsComponent, ItemTypes, EntityInventoryComponent, Block, Enchantment, MinecraftEnchantmentTypes } from "@minecraft/server"
import { system, Vector } from "@minecraft/server";
import { MinecraftEntityTypes, DynamicPropertiesDefinition } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"
import { onPlayerDeath } from "./player_corpse/death_coords";
import { replaceItemOnBroken } from "./replace_item_when_item_broke";
import { toolTip, targetIsOnRange, getHealthText } from "./info_ui/main_behavior";
import { backPack } from "./backpacks/backpack";

import * as Quests from "./bounty_system/constants/Quests.js";
import * as QuestStatus from "./bounty_system/constants/QuestStatus.js";

const advancements = [
    {
        name: "Getting an Upgrade!",
        item: "pog:stone_pickaxe",
        requiredAmount: 1,
        tag: "stone_pickaxe",
        title: "stone_pickaxe",
        epic: false,
    },
    {
        name: "Aquire Hardware!",
        item: "minecraft:iron_ingot",
        requiredAmount: 1,
        tag: "iron_ingot",
        title: "iron_ingot",
        epic: false,
    },
    {
        name: "Suit Up!",
        item: "minecraft:iron_chestplate",
        requiredAmount: 1,
        tag: "iron_chestplate",
        title: "iron_chestplate",
        epic: false,
    },
    {
        name: "Isn't It Iron Pick!",
        item: "pog:iron_pickaxe",
        requiredAmount: 1,
        tag: "iron_pickaxe",
        title: "iron_pickaxe",
        epic: true,
    },
    {
        name: "Potective Stave!",
        item: "minecraft:shield",
        requiredAmount: 1,
        tag: "shield",
        title: "shield",
        epic: true,
    },
    {
        name: "Don't Wild Carrots!",
        item: "better_on_bedrock:wild_carrot_food",
        requiredAmount: 1,
        tag: "wild_carrot",
        title: "wild_carrot",
        epic: true,
    },
    {
        name: "Coconut nut is a giant nut?",
        item: "better_on_bedrock:coconut_nut",
        requiredAmount: 1,
        tag: "coconut_nut",
        title: "coconut_nut",
        epic: false,
    },
    {
        name: "Sad Days.",
        item: "better_on_bedrock:ender_tear",
        requiredAmount: 1,
        tag: "ender_tear",
        title: "ender_tear",
        epic: true,
    },
    {
        name: "More Travels!",
        item: "better_on_bedrock:waystone",
        requiredAmount: 1,
        tag: "waystone",
        title: "waystone",
        epic: false,
    },
];

system.runInterval(
    (data) => {
        replaceItemOnBroken();
        toolTip();
        backPack();
        
        for (const player of world.getAllPlayers()) {
            if (player.hasTag( "allow_corpse" )) onPlayerDeath();
            
            const inventory = player.getComponent( "inventory" ).container;
            for (let slot = 0; slot < inventory.size; slot++) {
                const item = inventory.getItem( slot );
                const advancement = advancements.find(
                    (a) =>
                        item?.typeId == a.item
                        && item?.amount >= a.requiredAmount
                        && !player.hasTag( a.tag )
                );
                
                if (advancement) {
                    player.addTag( advancement.tag );
                    world.sendMessage(
                        "[§2" + player.nameTag + "§f] Made The Advancement: " + ( advancement.epic ? "§5" : "§e" ) + advancement.name
                    );
                    
                    player.playSound( advancement.epic ? "epic_quest" : "normal_quest" );
                    player.addTag( advancement.tag );
                    player.onScreenDisplay.setTitle( advancement.title );
                };
                
                if(
                    item?.typeId == "better_on_bedrock:disc_travelers"
                    && !item.getLore().length
                ) {
                    item.setLore([ "§r§7J. Rivers - Travelers" ]);
                    inventory.setItem( slot, item );
                };
                
                const quests = JSON.parse(player.getDynamicProperty( "quests" ));
                if (
                    item?.typeId === "minecraft:raw_iron"
                    && quests.find((q) => q.id == Quests.Metallis).status == QuestStatus.Busy
                ) {
                    quests.find((q) => q.id == Quests.Metallis).status = QuestStatus.Completed;
                    quests.find((q) => q.id == Quests.LightMyDay).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests",
                        JSON.stringify( quests ),
                    );
                } else if (
                    item?.typeId === "minecraft:coal"
                    && quests.find((q) => q.id == Quests.LightMyDay).status == QuestStatus.Busy
                ) {
                    quests.find((q) => q.id == Quests.LightMyDay).status = QuestStatus.Completed;
                    quests.find((q) => q.id == Quests.WitchcraftBlue).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests",
                        JSON.stringify( quests ),
                    );
                } else if (
                    item?.typeId === "minecraft:lapis_lazuli"
                    && item.amount >= 32
                    && quests.find((q) => q.id == Quests.WitchcraftBlue).status == QuestStatus.Busy
                ) {
                    quests.find((q) => q.id == Quests.WitchcraftBlue).status = QuestStatus.Completed;
                    quests.find((q) => q.id == Quests.Amethysts).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests",
                        JSON.stringify( quests ),
                    );
                } else if (
                    item?.typeId === "minecraft:amethyst_shard"
                    && item.amount >= 32
                    && quests.find((q) => q.id == Quests.Amethysts).status == QuestStatus.Busy
                ) {
                    quests.find((q) => q.id == Quests.Amethysts).status = QuestStatus.Completed;
                    quests.find((q) => q.id == Quests.Diamonds).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests",
                        JSON.stringify( quests ),
                    );
                } else if (
                    item?.typeId === "minecraft:diamond" && item.amount >= 9 && quests.find((q) => q.id == Quests.Diamonds).status == QuestStatus.Busy
                ) {
                    quests.find((q) => q.id == Quests.Diamonds).status = QuestStatus.Completed;
                    quests.find((q) => q.id == Quests.sadEnderman).status == QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.sendMessage("§9Tier Complete! Time To Mine.");
                    player.playSound( "epic_quest" );
                    player.setDynamicProperty(
                        "quests",
                        JSON.stringify( quests ),
                    );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests ),
                    );
                    player.setDynamicProperty(
                        "tiersCompleted",
                        1,
                    );
                }
                //tier 2
                 const quests2 = JSON.parse(player.getDynamicProperty( "quests2" ));
                if (
                    item?.typeId === "better_on_bedrock:ender_tear" && item.amount >= 4
                    && quests2.find((q) => q.id == Quests.sadEnderman).status == QuestStatus.Busy
                ) {
                    quests2.find((q) => q.id == Quests.sadEnderman).status = QuestStatus.Completed;
                    quests2.find((q) => q.id == Quests.bountyTime).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests2 ),
                    );
                } else  if (
                    item?.typeId === "minecraft:raw_iron" && item.amount >= 9
                    && quests2.find((q) => q.id == Quests.bountyTime).status == QuestStatus.Busy
                ) {
                    quests2.find((q) => q.id == Quests.bountyTime).status = QuestStatus.Completed;
                    quests2.find((q) => q.id == Quests.logCollector).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests2 ),
                    );
                } else  if (
                    item?.typeId === "minecraft:log" && item.amount >= 9
                    && quests2.find((q) => q.id == Quests.logCollector).status == QuestStatus.Busy
                ) {
                    quests2.find((q) => q.id == Quests.logCollector).status = QuestStatus.Completed;
                    quests2.find((q) => q.id == Quests.oreCollector).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests2 ),
                    );
                } else  if (
                    item?.typeId === "minecraft:coal_ore" && item.amount >= 9
                    && quests2.find((q) => q.id == Quests.oreCollector).status == QuestStatus.Busy
                ) {
                    quests2.find((q) => q.id == Quests.oreCollector).status = QuestStatus.Completed;
                    quests2.find((q) => q.id == Quests.evokerSpells).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests2 ),
                    );
                } else  if (
                    item?.typeId === "minecraft:emerald" && item.amount >= 9
                    && quests2.find((q) => q.id == Quests.evokerSpells).status == QuestStatus.Busy
                ) {
                    quests2.find((q) => q.id == Quests.evokerSpells).status = QuestStatus.Completed;
                    //quests2.find((q) => q.id == Quests.evokerSpells).status = QuestStatus.Unlocked;
                    player.sendMessage("§aQuest Complete! Go claim your reward!");
                    player.playSound( "normal_quest" );
                    player.setDynamicProperty(
                        "quests2",
                        JSON.stringify( quests2 ),
                    );
                }

            };
        };
    },
);