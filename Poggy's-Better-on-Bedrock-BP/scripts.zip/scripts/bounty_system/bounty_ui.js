import { world, Items, ItemStack, MinecraftEntityTypes, DynamicPropertiesDefinition, ItemTypes } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import "./quest_tiers/time_to_mine/quest_list.js";
import { time_to_mine } from "./quest_tiers/time_to_mine/quest_list.js";
import { adventure_delight } from "./quest_tiers/adventure_delight/quest_list.js";

import * as Quests from "./constants/Quests.js";
import * as QuestStatus from "./constants/QuestStatus.js";

world.events.worldInitialize.subscribe(
    ({ propertyRegistry }) => {
        const playerCompShowTick = new DynamicPropertiesDefinition();
        playerCompShowTick.defineBoolean( "showButton" );
        
        playerCompShowTick.defineNumber("gettinStarted");
        playerCompShowTick.defineNumber("tiersCompleted");
        playerCompShowTick.defineNumber("betterBedrock");
        
        playerCompShowTick.defineString( "quests", 102 );
        playerCompShowTick.defineString( "quests2", 102 );
        
        propertyRegistry.registerEntityTypeDynamicProperties(
            playerCompShowTick, MinecraftEntityTypes["player"]
        );
    },
);

const quests = [
    {
        id: Quests.Metallis,
        status: QuestStatus.Unlocked,
    },
    {
        id: Quests.LightMyDay,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.WitchcraftBlue,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.Amethysts,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.Diamonds,
        status: QuestStatus.Locked,
    },
];
const quests2 = [
    {
        id: Quests.sadEnderman,
        status: QuestStatus.Unlocked,
    },
    {
        id: Quests.bountyTime,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.logCollector,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.oreCollector,
        status: QuestStatus.Locked,
    },
    {
        id: Quests.evokerSpells,
        status: QuestStatus.Locked,
    },
];

world.events.playerSpawn.subscribe(
    ({ player }) => {
        if (!player. getDynamicProperty( "quests" )) {
            player.setDynamicProperty(
                "quests",
                JSON.stringify( quests ),
            );
        };
        if (!player. getDynamicProperty( "quests2" )) {
            player.setDynamicProperty(
                "quests2",
                JSON.stringify( quests ),
            );
        };
    },
);

const randomXP = Math.floor(Math.random() * 64) + 32;
const bounty_tier_page = ( player ) => {
    const tiersCompleted = player.getDynamicProperty( "tiersCompleted" );
    
    const form = new ActionFormData();
    form.title( "§fQuest Tiers" )
    form.body( "This is the tier list. Complete Tiers to unlock the next." );
    
    if (tiersCompleted  >= 0)
        form.button( "Time to Mine\n[§aUnlocked§r]", "textures/items/raw_iron" );
    else
        form.button( "Time to Mine\n[§cLocked§r]", "textures/items/raw_iron" );

    if (tiersCompleted >= 1)
        form.button( "Adventure Delight\n[§aUnlocked§r]", "textures/items/diamond_boots" );
    else
        form.button( "Adventure Delight\n[§cLocked§r]", "textures/items/diamond_boots" );
      
    form.button( "Monster Looter!\n[§cLocked§r]", "textures/items/rotten_flesh" )
    form.button( "Beyond the Overworld\n[§cLocked§r]", "textures/items/netherite_ingot" )
    form.button( "The Willager\n[§aAvailable§r]", "textures/items/dragons_breath" )
    form.button( "§fMore Food?\n[§aAvailable§r]", "textures/items/apple" )
    
    form.show( player ).then(
        (response) => {
            switch (response?.selection) {
                case 0:
                    if (player.getDynamicProperty("tiersCompleted")  >= 0)
                        time_to_mine( player );
                break;
                case 1:
                    if (player.getDynamicProperty("tiersCompleted")  >= 1)
                        adventure_delight( player );
                break;
            };
        },
    );
};

world.events.beforeItemUse.subscribe(
    ({ source: player, item }) => {
        switch (item?.typeId) {
            case "better_on_bedrock:quest_paper":
                const inventory = player.getComponent( "inventory" ).container;
                const newItem = new ItemStack(ItemTypes?.get("better_on_bedrock:bounty_paper_open"));
                
                inventory.setItem( player.selectedSlot, newItem );
            break;
            case "better_on_bedrock:bounty_paper_open": bounty_tier_page( player ); break;
        };
    },
);