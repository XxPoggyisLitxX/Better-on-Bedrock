/*import { ActionFormData } from "@minecraft/server-ui";
export const adventure_delight = ( player ) => {
    const form = new ActionFormData();
    form.title( "§fAdventure Delight");
    form.body( "Complete Quests To Unlock The Next Tier");

    form.button( "Sad Enderman\n[§cLocked]", "textures/items/waystone/ender_tear" );
    form.button( "Bounty Time!\n[§cLocked]", "textures/items/bounty_system/bounty_scroll_closed" );
    form.button( "Log Collector\n[§cLocked]", "textures/items/stick" );
    form.button( "Ore Collector\n[§cLocked]", "textures/items/copper_ingot" );
    form.button( "Ahoy!\n[§cLocked]", "textures/items/spyglass" );
    form.button( "Evoker Spells\n[§cLocked]", "textures/items/emerald" );

    form.show( player );
};*/

import { ActionFormData } from "@minecraft/server-ui";

import * as Quests from "../../constants/Quests.js";
import * as QuestStatus from "../../constants/QuestStatus.js";

const getFormattedStatus = ( status ) => {
    if (status == 0) return "§dLocked§r";
    else if (status == 1) return "§aUnlocked§r";
    else if (status == 2) return "§dBusy§r";
    else if (status == 3) return "§aCompleted§r";
    else if (status == 4) return "§aClaimed§r";
};

const quests = [
    {
        id: Quests.sadEnderman,
        name: "Sad Enderman",
        icon: "textures/items/waystone/ender_tear",
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fStone Age" );
            form.body( "Get 4 Ender Tears.\nRewards: 2 Iron Ingots\n100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title( "Start Quest?" );
            form.body( "Get 4 Ender Tears\nRewards: 2 Raw Iron\n100 xp" );
            form.button( "Start Quest!" );
            form.button( "Cancel" );
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_1");
                            player.onScreenDisplay.setTitle('sadEndermanQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.sadEnderman).status = QuestStatus.Busy;
                            console.warn(savedQuests.find((q) => q.id == Quests.sadEnderman).status);
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title("§fStone Age");
            form.body("Claim: 2 Iron Ingots for the completion of quest: 'Sad Enderman'.\n100 xp");
            form.button("Claim");
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.sadEnderman);
                            console.warn(quest.status != QuestStatus.Claimed);
                            if (quest.status != QuestStatus.Claimed) {
                                console.warn(quest.status);
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.bountyTime,
        name: "Bounty Time",
        icon: "textures/items/bounty_system/bounty_scroll_closed",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fBounty Time" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'sadEnderman'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fBounty Time" );
            form.body( "Get a Bounty Scroll.\nRewards: 2 Raw Iron\n100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
             const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
             const form = new ActionFormData()
             form.title("Start Quest?")
             form.body("Get a Bounty Scroll.\nRewards: 2 Raw Iron\n100 xp")
             form.button("Start Quest!")
             form.button("Cancel")
             form.show( player ).then(
                 (response) => {
                     switch (response?.selection) {
                         case 0:
                             player.removeTag("unlocked_2")
                             player.onScreenDisplay.setTitle('bountyTimeQuestStart')
                             player.sendMessage("§aQuest Started!")
                             savedQuests.find((q) => q.id == Quests.bountyTime).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                         break;
                     };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fBounty Time")
            form.body("Claim: 2 Raw Iron\n100 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.bountyTime);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.logCollector,
        name: "Witchcraft Blue",
        icon: "textures/items/stick",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLog Collector" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Evoker Spells'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title("§fLog Collector");
            form.body("Get All Stripped Log Variants.\nRewards:100 xp");
            form.button("Ok");
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title("Start Quest?");
            form.body("Get All Stripped Log Variants.\nRewards:100 xp");
            form.button("Start Quest!");
            form.button("Cancel");
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_3");
                            player.onScreenDisplay.setTitle('logCollectorQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.logCollector).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title( "§fLog Collector" );
            form.body( "Claim: 100 xp" );
            form.button( "Claim" );
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.logCollector);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.oreCollector,
        name: "Ore Collector",
        icon: "textures/items/copper_ingot",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fOre Collector" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Witchcraft Blue'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fOre Collector" );
            form.body( "Get All Ore Blocks.\nRewards:100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("Start Quest?")
            form.body("Get Get All Ore Blocks.\nRewards:100 xp")
            form.button("Start Quest!")
            form.button("Cancel")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_4");
                            player.onScreenDisplay.setTitle('oreCollectorQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.oreCollector).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fOre Collector")
            form.body("Claim: 100 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.oreCollector);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.evokerSpells,
        name: "Evoker Spells",
        icon: "textures/items/emerakd",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fEvoker Spells" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Witchcraft Blue'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData()
            form.title( "§fEvoker Spells" );
            form.body( "Get a Totem.\nRewards:100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("Start Quest?")
            form.body("Get a Totem.\nRewards:100 xp")
            form.button("Start Quest!")
            form.button("Cancel")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_5");
                            player.onScreenDisplay.setTitle('non');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.evokerSpellss).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fEvoker Spells")
            form.body("Claim: 200 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.evokerSpellss);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 200" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
];

export const adventure_delight = ( player ) => {
    let savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
    for (const questO of quests) {
        const qBefore = savedQuests.find((q) => q.id == (questO.id - 1));
        if (!savedQuests.find((q) => q.id == questO.id)) {
            savedQuests.push(
                {
                    id: questO.id,
                    status: (
                        qBefore.status == QuestStatus.Completed
                            ? QuestStatus.Unlocked
                            : QuestStatus.Locked
                    ),
                },
            );
        };
    };
    
    for (const savedQuest of savedQuests) {
        if (!quests.find((q) => q.id == savedQuest.id)) {
            savedQuests = savedQuests.filter((q) => q.id != savedQuest.id);
        };
    };
    
    player.setDynamicProperty(
        "quests",
        JSON.stringify( savedQuests ),
    );
    
    const form = new ActionFormData();
    form.title( "§fAdventure Delight" );
    form.body( "Complete Quests To Unlock The Next Tier" );
    
    for (const questO of quests) {
        const quest = savedQuests.find((q) => q.id == questO.id);
        const questStatus = getFormattedStatus(quest.status);
        
        form.button( questO.name + "\n[" + questStatus + "§r]", questO.icon );
    };
    
    form.show( player ).then(
        (response) => {
            if (response.canceled) return;
            const quest = savedQuests.find((q) => q.id == response.selection);
            const q = quests.find((q) => q.id == response.selection);
            
            if (quest.status == QuestStatus.Locked) q.locked( player );
            else if (quest.status == QuestStatus.Unlocked) q.start( player );
            else if (quest.status == QuestStatus.Busy) q.info( player );
            else if (quest.status == QuestStatus.Completed) q.claim( player );
        },
    );
};