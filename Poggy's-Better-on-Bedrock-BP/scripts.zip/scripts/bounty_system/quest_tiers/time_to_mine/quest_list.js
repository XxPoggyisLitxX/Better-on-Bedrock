import { ActionFormData } from "@minecraft/server-ui";

import * as Quests from "../../constants/Quests.js";
import * as QuestStatus from "../../constants/QuestStatus.js";

const getFormattedStatus = ( status ) => {
    if (status == 0) return "§dLocked§r";
    else if (status == 1) return "§aUnlocked§r";
    else if (status == 2) return "§dBusy§r";
    else if (status == 3) return "§aCompleted§r";
    else if (status == 4) return "§aClaimed§r";
};

const quests = [
    {
        id: Quests.Metallis,
        name: "Metallis",
        icon: "textures/items/raw_iron",
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fStone Age" );
            form.body( "Get a Raw Iron Ingot.\nRewards: 2 Iron Ingots\n100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title( "Start Quest?" );
            form.body( "Get Coal.\nRewards: 2 Raw Iron\n100 xp" );
            form.button( "Start Quest!" );
            form.button( "Cancel" );
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_1");
                            player.onScreenDisplay.setTitle('metallisQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.Metallis).status = QuestStatus.Busy;
                            console.warn(savedQuests.find((q) => q.id == Quests.Metallis).status);
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title("§fStone Age");
            form.body("Claim: 2 Iron Ingots\n100 xp");
            form.button("Claim");
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.Metallis);
                            console.warn(quest.status != QuestStatus.Claimed);
                            if (quest.status != QuestStatus.Claimed) {
                                console.warn(quest.status);
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.LightMyDay,
        name: "Light My Day",
        icon: "textures/items/coal",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Metallis'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "Get Coal.\nRewards: 2 Raw Iron\n100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
             const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
             const form = new ActionFormData()
             form.title("Start Quest?")
             form.body("Get Coal.\nRewards: 2 Raw Iron\n100 xp")
             form.button("Start Quest!")
             form.button("Cancel")
             form.show( player ).then(
                 (response) => {
                     switch (response?.selection) {
                         case 0:
                             player.removeTag("unlocked_2")
                             player.onScreenDisplay.setTitle('light_my_dayQuestStart')
                             player.sendMessage("§aQuest Started!")
                             savedQuests.find((q) => q.id == Quests.LightMyDay).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                         break;
                     };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fLight My Day")
            form.body("Claim: 2 Raw Iron\n100 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.LightMyDay);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.WitchcraftBlue,
        name: "Witchcraft Blue",
        icon: "textures/items/dye_powder_blue",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Light My Day'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title("§fLight My Day");
            form.body("Get 32 Lapis Lazuli.\nRewards:100 xp");
            form.button("Ok");
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title("Start Quest?");
            form.body("Get 32 Lapis Lazuli.\nRewards:100 xp");
            form.button("Start Quest!");
            form.button("Cancel");
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_3");
                            player.onScreenDisplay.setTitle('witchcraft_blueQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.WitchcraftBlue).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "Claim: 100 xp" );
            form.button( "Claim" );
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.WitchcraftBlue);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.Amethysts,
        name: "Amethysts",
        icon: "textures/items/amethyst_shard",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Witchcraft Blue'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "Get 32 Amethyst Shards.\nRewards:100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("Start Quest?")
            form.body("Get 32 Amethyst Shards.\nRewards:100 xp")
            form.button("Start Quest!")
            form.button("Cancel")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_4");
                            player.onScreenDisplay.setTitle('amethystQuestStart');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.Amethysts).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fLight My Day")
            form.body("Claim: 100 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.Amethysts);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 100" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
    {
        id: Quests.Diamonds,
        name: "Diamonds???",
        icon: "textures/items/diamond",
        locked: ( player ) => {
            const form = new ActionFormData();
            form.title( "§fLight My Day" );
            form.body( "§cTo unlock this quest, you need to complete and claim rewards of quest: 'Witchcraft Blue'." );
            form.button( "Ok" );
            form.show( player );
        },
        info: ( player ) => {
            const form = new ActionFormData()
            form.title( "§fLight My Day" );
            form.body( "Get 9 Diamond Shards.\nRewards:100 xp" );
            form.button( "Ok" );
            form.show( player );
        },
        start: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("Start Quest?")
            form.body("Get 9 Diamond Shards.\nRewards:100 xp")
            form.button("Start Quest!")
            form.button("Cancel")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            player.removeTag("unlocked_5");
                            player.onScreenDisplay.setTitle('non');
                            player.sendMessage("§aQuest Started!");
                            savedQuests.find((q) => q.id == Quests.Diamonds).status = QuestStatus.Busy;
                            player.setDynamicProperty(
                                "quests",
                                JSON.stringify( savedQuests ),
                            );
                        break;
                    };
                },
            );
        },
        claim: ( player ) => {
            const savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
            const form = new ActionFormData()
            form.title("§fLight My Day")
            form.body("Claim: 200 xp")
            form.button("Claim")
            form.show( player ).then(
                (response) => {
                    switch (response?.selection) {
                        case 0:
                            const quest = savedQuests.find((q) => q.id == Quests.Diamonds);
                            if (quest.status != QuestStatus.Claimed) {
                                player.runCommandAsync( "xp 200" );
                                player.runCommandAsync( "give @s iron_ingot 2" );
                                quest.status = QuestStatus.Claimed;
                                player.setDynamicProperty(
                                    "quests",
                                    JSON.stringify( savedQuests ),
                                );
                            };
                        break;
                    };
                },
            );
        },
    },
];

export const time_to_mine = ( player ) => {
    let savedQuests = JSON.parse(player.getDynamicProperty( "quests" ));
    for (const questO of quests) {
        const qBefore = savedQuests.find((q) => q.id == (questO.id - 1));
        if (!savedQuests.find((q) => q.id == questO.id)) {
            savedQuests.push(
                {
                    id: questO.id,
                    status: (
                        qBefore.status == QuestStatus.Completed
                            ? QuestStatus.Unlocked
                            : QuestStatus.Locked
                    ),
                },
            );
        };
    };
    
    for (const savedQuest of savedQuests) {
        if (!quests.find((q) => q.id == savedQuest.id)) {
            savedQuests = savedQuests.filter((q) => q.id != savedQuest.id);
        };
    };
    
    player.setDynamicProperty(
        "quests",
        JSON.stringify( savedQuests ),
    );
    
    const form = new ActionFormData();
    form.title( "§fTime to Mine" );
    form.body( "Complete Quests To Unlock The Next Tier" );
    
    for (const questO of quests) {
        const quest = savedQuests.find((q) => q.id == questO.id);
        const questStatus = getFormattedStatus(quest.status);
        
        form.button( questO.name + "\n[" + questStatus + "§r]", questO.icon );
    };
    
    form.show( player ).then(
        (response) => {
            if (response.canceled) return;
            const quest = savedQuests.find((q) => q.id == response.selection);
            const q = quests.find((q) => q.id == response.selection);
            
            if (quest.status == QuestStatus.Locked) q.locked( player );
            else if (quest.status == QuestStatus.Unlocked) q.start( player );
            else if (quest.status == QuestStatus.Busy) q.info( player );
            else if (quest.status == QuestStatus.Completed) q.claim( player );
        },
    );
};