import { world, Items, ItemStack, MinecraftEntityTypes, DynamicPropertiesDefinition, ItemTypes } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";

world.events.worldInitialize.subscribe(
    (data) => {
        const iCompShowTick = new DynamicPropertiesDefinition();
        data.propertyRegistry.registerEntityTypeDynamicProperties(
            iCompShowTick, MinecraftEntityTypes["player"]
        );
    },
);

const randomXP = Math.floor(Math.random() * 64) + 32;
const quests = [
    {
        id: 0,
        name: "Cow Slayer",
        tag: "cow_bounty",
        functions: {
            start: ( player ) => {
                 const form = new ActionFormData();
                 form.title( "Cow Slayer I" );
                 form.body( "Hunt down 3 cows.\nRewards: 20xp, 22 coal" );
                 form.button( "Start Hunt" );
                 form.button( "Not Now" );
                 form.show( player ).then(
                     (response) => {
                         switch (response?.selection) {
                             case 0:
                                 player.removeTag( "cow_bounty_open" );
                                 player.addTag( "cow_bounty_started" );
                             break;
                         };
                    },
                );
            },
            about: ( player ) => {
                 const form = new ActionFormData();
                 form.title( "Cow Slayer I" );
                 form.body( "Hunt down 3 cows.\nRewards: 20xp, 22 coal" );
                 form.button( "Got It!" );
                 form.show( player );
            },
            claim: ( player ) => {
                const form = new ActionFormData();
                form.title("Cow Slayer I");
                form.body("You hunted down 3 cows so you can claim your rewards:\nRewards: 20xp, 22 coal");
                form.button("Got It!");
                form.show( player ).then(
                    (response) => {
                        switch (response?.selection) {
                            case 0:
                                if (i.hasTag( "cow_claimed_I" )) {
                                    i.removeTag( "cow_claimed_I" );
                                    i.runCommandAsync( "give @s coal 22" );
                                };
                            break;
                        };
                    },
                );
            },
        },
    },
];

const bounty_tier_page = ( player ) => {
    const form = new ActionFormData();
    form.title("§fBounties");
    form.body("Welcome to the bounty screen. Select an exisitng bounty, or a newly unlocked bounty and follow the instructions. Each bounty will have a difficulty indicated by 'I, II, III, IV, V'.");
    
    for (const quest of quests)
        form.button(
            quest.name + " | " + getFormattedStatus(getBountyStatus( player, quest.tag )),
        );
    
    form.show( player ).then(
        (response) => {
            console.warn(response?.selection);
            
            if (reponse.canceled) return;
            const quest = quests.find((q) => q.id == response.selection);
            console.warn(quest.tag);
            const status = getBountyStatus( player, quest.tag );
            console.warn(status);
            
            if (status == 0) quest.functions.start( player );
            else if (status == 1) quest.functions.about( player );
            else if (status == 2) quest.functions.claim( player );
        },
    );
};

world.events.beforeItemUse.subscribe(
    ({ source: player, item }) => {
        switch (item?.typeId) {
            case "better_on_bedrock:quest_scroll_closed":
                player.addTag( "cow_bounty_open" )
                const inventory = player.getComponent( "inventory" ).container;
                const newItem = new ItemStack(ItemTypes?.get("better_on_bedrock:quest_scroll_opened"));
                
                inventory.setItem( player.selectedSlot, newItem );
            break;
            case "better_on_bedrock:quest_scroll_opened": bounty_tier_page( player ); break;
        };
    },);

const getBountyStatus = ( player, questName ) => {
    if (player.hasTag( questName + "_open" )) return 0;
    else if (player.hasTag( questName + "_busy" )) return 1;
    else if (player.hasTag( questName + "_completed" )) return 2;
};

const getFormattedStatus = ( status ) => {
    if (status == 0) return "§dOpen";
    else if (status == 1) return "§cSearching Bounty...";
    else if (status == 2) return "§aBounty Found!";
};