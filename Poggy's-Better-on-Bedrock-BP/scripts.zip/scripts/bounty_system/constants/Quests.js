export const Metallis = 0;
export const LightMyDay = 1;
export const WitchcraftBlue = 2;
export const Amethysts = 3;
export const Diamonds = 4;

//tier 2
export const sadEnderman = 0;
export const bountyTime = 1;
export const logCollector = 2;
export const oreCollector = 3;
export const ahoy = 4;
export const evokerSpells = 5;