import { world, Items, ItemStack, Entity, ItemEnchantsComponent, ItemTypes, EntityInventoryComponent, Block, Enchantment, MinecraftEnchantmentTypes } from "@minecraft/server"
import { system } from "@minecraft/server";
import { MinecraftEntityTypes, DynamicPropertiesDefinition } from "@minecraft/server"
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui"

function hardcoreUI(player, ui = undefined) {
    if(!ui) ui = uiForHardcore(player);
    ui.show(player).then(response => {
        if(response.cancelationReason == "userBusy") {
          hardcoreUI(player, ui);
            return;
        } else if(response.cancelationReason == "userClosed") {
            return;
        }
          let [ dropdown, toggle1, toggle2, toggle3 ] = response.formValues
          if(dropdown == 0){
              player.runCommandAsync("difficulty easy")
              player.addTag("selected2")
              player.setDynamicProperty('tiersCompleted', 0)
              player.runCommandAsync("function run_tags")
              player.runCommandAsync("give @p better_on_bedrock:quest_paper")
              player.sendMessage("§eDifficulty set to §aEasy")
              player.removeTag("selected")
          }
           if(dropdown == 1){
              player.runCommandAsync("difficulty normal")
              player.addTag("selected2")
              player.setDynamicProperty('tiersCompleted', 0)
              player.runCommandAsync("function run_tags")
              player.runCommandAsync("give @p better_on_bedrock:quest_paper")
              player.sendMessage("§eDifficulty set to §eNormal")
              player.removeTag("selected")
          }
           if(dropdown == 2){
            player.setDynamicProperty('tiersCompleted', 0)
              player.runCommandAsync("difficulty hard")
              player.addTag("selected2")
              player.runCommandAsync("function run_tags")
              player.runCommandAsync("give @p better_on_bedrock:quest_paper")
               player.sendMessage("§eDifficulty set to §cHard")
               player.removeTag("selected")
          }
           if(dropdown == 3){
              player.runCommandAsync("difficulty hard")
              player.addTag("selected")
              player.setDynamicProperty('tiersCompleted', 0)
              player.runCommandAsync("function run_tags")
              player.runCommandAsync("give @p better_on_bedrock:quest_paper")
               player.sendMessage("§eDifficulty set to §4Hardcore")
          }
          if(toggle1 == true) {
              player.sendMessage("§eItem Info: §aYes")
          } else if(toggle1 == false) {
              player.sendMessage("§eItem Info: §cNo")
          }
          if(toggle2 == true) {
              player.runCommandAsync("give @p digger_test:copper_axe_2")
              player.runCommandAsync("give @p pog:wood_axe")
              player.runCommandAsync("give @p leather_chestplate")
              player.sendMessage("§eStarter Loot: §aYes")
          }else if(toggle2 == false) {
              player.sendMessage("§eStarter Loot: §cNo")
          }
           if(toggle3 == true) {
              player.addTag("allow_corpse")
              player.sendMessage("§eAllow Corpse: §aYes")
          }else if(toggle3 == false) {
               player.sendMessage("§eAllow Corpse: §cNo")
              player.removeTag("allow_corpse")
          }
    });
  }

  export function uiForHardcore(player) {
    let form = new ModalFormData()
    form.title("Add-On Config")
    form.dropdown('Select Your Config!\n\nSelect Gamemode\nSelection will stay permanent', ["Easy", "Normal", "Hard", "Hardcore"], 1)
    form.toggle("Guide Book")
    form.toggle("Starter Tools")
    form.toggle("Corpse On Death")
  return form;
}
function showWelcomeMessage(player) {
  // Get the player's name
  let playerName = player.name;

  // Display the welcome message to the player
  console.warn(`Welcome to the world, ${playerName}!`);
}

world.events.playerSpawn.subscribe((ev) => {

// Define a function that displays a welcome message to the player

// When the world loads, show the welcome message to the player

ev.player.setDynamicProperty("tiersCompleted", 0)
  ev.player.setDynamicProperty("gettinStarted", 3)
  ev.player.setDynamicProperty("better_on_bedrock", 10)
  console.warn(ev.player.getDynamicProperty("gettinStarted"))
  if (!ev.player.hasTag("selected") && !ev.player.hasTag("selected2")){
    showWelcomeMessage(ev.player)
    hardcoreUI(ev.player);
    ev.player.setDynamicProperty("showButton", true)
}
}
);