import { world, Player } from "@minecraft/server"
let cowAmount = 0

world.events.entityDie.subscribe(({deadEntity, damageSource: {damagingEntity}}) => {
    if(!(damagingEntity instanceof Player)) return;
    let cowValue = damagingEntity.getDynamicProperty('cowBounty_amount')
    if(deadEntity.typeId == 'minecraft:cow' && (damagingEntity.getDynamicProperty('cowBounty_busy') == true)){
        cowAmount 
        console.warn(cowValue )
        damagingEntity.setDynamicProperty('cowBounty_amount', cowValue += 1) 
    }
})