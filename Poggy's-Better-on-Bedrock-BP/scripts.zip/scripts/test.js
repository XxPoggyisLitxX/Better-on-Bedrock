import { world, ItemStack, ItemTypes } from "@minecraft/server"
import { system } from "@minecraft/server";
system.events.beforeWatchdogTerminate.subscribe(data => {
  data.cancel = true;
});

world.events.itemReleaseCharge.subscribe(ev => {
  for (const player of world.getPlayers()) {
    let inv = player.getComponent('inventory').container
    const itemStack = inv.getItem(player.selectedSlot);
    if (itemStack?.typeId === 'tlc:iron_spear') {
      var container = player.getComponent('inventory').container
      var newItem = new ItemStack(ItemTypes?.get("tlc:iron_spear"));
      var oldItem = container?.getItem(player.selectedSlot)
      player.removeTag("iron_spear")
    }
    let e = system.runInterval(() => {
      if (player.hasTag("iron_spear") && itemStack?.typeId === 'tlc:iron_spear' && itemStack?.getComponent("durability").damage <= 125) {
        player.removeTag("iron_spear")
        newItem.getComponent("durability").damage = oldItem.getComponent("durability").damage + 1;
        container.setItem(player.selectedSlot, newItem);
        if (!player.hasTag("iron_spear")) {
          system.clearRun(e)
      }
      }
    })
  }
})