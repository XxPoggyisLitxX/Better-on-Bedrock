import { world, ItemStack, MinecraftEntityTypes, DynamicPropertiesDefinition, ItemTypes } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

import * as Bounties from "./constants/Bounties.js";
import * as BountyStatus from "./constants/BountyStatus.js";

world.events.worldInitialize.subscribe(
    ({ propertyRegistry }) => {
        const playerCompShowTick = new DynamicPropertiesDefinition();
        
        playerCompShowTick.defineString( "bounties", 162 );
        //wait
        //okay
            
        propertyRegistry.registerEntityTypeDynamicProperties(
            playerCompShowTick, MinecraftEntityTypes["player"]
        );
    },
);

const getFormattedStatus = ( status ) => {
    if (status == 0) return "§dOpen";
    else if (status == 1) return "§cSearching Bounty...";
    else if (status == 2) return "§aBounty Found!";
    else if (status == 3) return "§dClaimed";
    else if (status == 4) return "§cClosed";
};

const bounties = [
    {
        id: Bounties.CowSlayer,
        p: 0,
        s: BountyStatus.Open,
    },
    {
        id: Bounties.ZombieHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
    {
        id: Bounties.PigHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
    {
        id: Bounties.SheepHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
    {
        id: Bounties.GhastHunter,
        p: 0,
        s: BountyStatus.Closed,
    },

    {
        id: Bounties.WillagerHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
    {
        id: Bounties.LichHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
    {
        id: Bounties.EnchanterHunter,
        p: 0,
        s: BountyStatus.Closed,
    },
];

const quests = [
    {
        id: Bounties.CowSlayer,
        name: "Cow Slayer I",
        description: "Hunt down 3 Cows.",
        rewards: "24 Coal and 20 XP",
        commands: [
            "xp 20",
            "give @s coal 24",
        ],
    },
    {
        id: Bounties.ZombieHunter,
        name: "Zombie Slayer II",
        description: "Hunt down 8 Zombie.",
        rewards: "24 Coal and 20 XP",
        commands: [
            "xp 20",
            "give @s coal 24",
        ],
    },
    {
        id: Bounties.PigHunter,
        name: "Pig Hunter I",
        description: "Hunt down 5 Pigs.",
        rewards: "16 Cobblestone and 25 XP",
        commands: [
            "xp 25",
            "give @s cobblestone 16",
        ],
    },
    {
        id: Bounties.SheepHunter,
        name: "Sheep Hunter I",
        description: "Hunt down 4 Sheeps.",
        rewards: "4 Wild Carrots and 35 XP",
        commands: [
            "xp 35",
            "give @s better_on_bedrock:wild_carrot_food 4",
        ],
    },
    {
        id: Bounties.GhastHunter,
        name: "Ghast Hunter I",
        description: "Hunt down 3 Ghasts.",
        rewards: "8 Iron Ingots and 50 XP",
        commands: [
            "xp 50",
            "give @s iron_ingot 8",
        ],
    },

    {
        id: Bounties.WillagerHunter,
        name: "Willager Hunter I",
        description: "Hunt down a Willager.",
        rewards: "1 Totem of Undying and 100 XP",
        commands: [
            "xp 100",
            "give @s totem",
        ],
    },
    {
        id: Bounties.LichHunter,
        name: "Lich Hunter I",
        description: "Hunt down a Lich.",
        rewards: "2 Golden Apples and 125 XP",
        commands: [
            "xp 125",
            "give @s golden_apple 2",
        ],
    },
    {
        id: Bounties.EnchanterHunter,
        name: "Enchanter Hunter I",
        description: "Hunt down an Enchanter.",
        rewards: "1 Enchanted Golden Apple and 150 XP",
        commands: [
            "xp 150",
            "give @s enchanted_golden_apple",
        ],
    },
];

const functions = {
    start: ( player, bounty ) => {
        const savedBounties = JSON.parse(player.getDynamicProperty( "bounties" ));
        const form = new ActionFormData();
        form.title( bounty.name );
        form.body( bounty.description + "\n§7Rewards: " + bounty.rewards );
        form.button( "Start Hunt" );
        form.button( "Not Now" );
        form.show( player ).then(
            (response) => {
                switch (response?.selection) {
                    case 0:
                        if (savedBounties.find((b) => b.s == BountyStatus.Busy)) return player.sendMessage( "§cYou're already doing a different bounty!" );
                        player.sendMessage( "§aQuest Started!" );
                        savedBounties.find((b) => b.id == bounty.id).s = BountyStatus.Busy;
                        player.setDynamicProperty(
                            "bounties",
                            JSON.stringify( savedBounties ),
                        );
                    break;
                };
            },
        );
    },
    about: ( player, bounty ) => {
        const form = new ActionFormData();
        form.title( bounty.name );
        form.body( bounty.description + "\n§7Rewards: " + bounty.rewards );
        form.button( "Got It!" );
        form.show( player );
    },
    claim: ( player, bounty ) => {
        const savedBounties = JSON.parse(player.getDynamicProperty( "bounties" ));
        const form = new ActionFormData();
        form.title( bounty.name );
        form.body( "Bounty completed, claim your reward!\n§7Rewards: " + bounty.rewards );
        form.button( "Claim!" );
        form.show( player ).then(
            (response) => {
                switch (response?.selection) {
                    case 0:
                        const bounty = savedBounties.find((b) => b.id == bounty.id);
                        const b = quests.find((b) => b.id == bounty.id);
                        if (bounty.s != BountyStatus.Claimed) {

                            for (const command of b.commands) {
                                player.runCommandAsync( command );
                            };

                            bounty.s = BountyStatus.Claimed;
                            player.setDynamicProperty(
                                "bounties",
                                JSON.stringify( savedBounties ),
                            );
                        };
                    break;
                };
            },
        );
    },
};

export const bounty_tier_page = ( player ) => {
    let savedBounties = JSON.parse(player.getDynamicProperty( "bounties" ));
    for (const savedBounty of savedBounties) {
        if (!quests.find((q) => q.id == savedBounty.id)) {
            savedBounties = savedBounties.filter((q) => q.id != savedBounty.id);
        };
    };
    
    player.setDynamicProperty(
        "bounties",
        JSON.stringify( savedBounties ),
    );
    
    const form = new ActionFormData();
    form.title( "§fBounties" );
    form.body( "Welcome to the bounty screen. Select an exisitng bounty, or a newly unlocked bounty and follow the instructions. Each bounty will have a difficulty indicated by 'I, II, III, IV, V'." );
    
    for (const questO of quests) {
        const quest = savedBounties.find((b) => b.id == questO.id);
        const questStatus = getFormattedStatus(quest.s);
        
        form.button(
            (
                quest.s == BountyStatus.Open
                || quest.s == BountyStatus.Closed
                    ? "§7"
                    : "§f"
            )
            + questO.name + " - " + questStatus,
            questO.icon
        );
        
        /*form.button('Zombie Hunter III')
        form.button('Phantom Hunter IV')
        form.button('Deer Hunter II')
        form.button('Spider Hunter V')
        form.button('Skeleton Hunter III')
        form.button('Blaze Hunter III')
        form.button('Piglin Brute Hunter V')
        form.button('Vex Hunter III')
        form.button('Enderman Hunter IV')
        form.button('Vindicator Hunter II')
        form.button('Witch Hunter II')
        form.button('Evoker Hunter IV')
        form.button('Ravanger Hunter III')*/
    };
    
    form.show( player ).then(
        (response) => {
            if (response.canceled) return;
            const bounty = savedBounties.find((b) => b.id == response.selection);
            const b = quests.find((b) => b.id == response.selection);
            
            if (bounty.s == BountyStatus.Open) functions.start( player, b );
            else if (bounty.s == BountyStatus.Busy) functions.about( player, b );
            else if (bounty.s == BountyStatus.Completed) functions.claim( player, b );
        },
    );
};

world.events.beforeItemUse.subscribe(
    ({ source: player, item }) => {
        try {
        switch (item?.typeId) {
            case "better_on_bedrock:quest_scroll_closed":
                player.addTag( "cow_bounty_open" )
                const inventory = player.getComponent( "inventory" ).container;
                const newItem = new ItemStack(ItemTypes?.get("better_on_bedrock:quest_scroll_opened"));
                
                inventory.setItem( player.selectedSlot, newItem );
            break;
            case "better_on_bedrock:quest_scroll_opened":
                if (!player.getDynamicProperty( "bounties" )) {
                    player.setDynamicProperty(
                        "bounties",
                        JSON.stringify( bounties ),
                    );
                };

                bounty_tier_page( player );
            break;
        };
        } catch(e) {
            player.sendMessage( "" + e );
        };
    },
);