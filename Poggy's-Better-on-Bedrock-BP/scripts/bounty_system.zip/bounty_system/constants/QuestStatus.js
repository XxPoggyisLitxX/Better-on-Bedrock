export const Locked = 0;
export const Unlocked = 1;
export const Busy = 2;
export const Completed = 3;
export const Claimed = 4;