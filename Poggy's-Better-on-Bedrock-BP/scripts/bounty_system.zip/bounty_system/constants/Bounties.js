export const CowSlayer = 0;
export const PigHunter = 1;
export const SheepHunter = 2;
export const GhastHunter = 3;

export const WillagerHunter = 4;
export const LichHunter = 5;
export const EnchanterHunter = 6;