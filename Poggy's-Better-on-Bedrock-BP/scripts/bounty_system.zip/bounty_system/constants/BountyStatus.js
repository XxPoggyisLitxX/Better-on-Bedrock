export const Open = 0;
export const Busy = 1;
export const Completed = 2;
export const Claimed = 3;