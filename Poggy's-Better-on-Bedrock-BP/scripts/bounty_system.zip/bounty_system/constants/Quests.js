//Time to Mine
export const Metallis = 0;
export const LightMyDay = 1;
export const WitchcraftBlue = 2;
export const Amethysts = 3;
export const Diamonds = 4;

//Adventure Delight
export const sadEnderman = 0;
export const bountyTime = 1;
export const logCollector = 2;
export const oreCollector = 3;
export const evokerSpells = 4;

//Monster Looter
export const ZombieSlayer = 0;
export const CreeperHunter = 1;
export const StringySituation = 2;
export const MoreSouls = 3;

//Beyond the Overworld
export const ThatsFine = 0;
export const Snowwhite = 1;
export const Netherite = 2;
export const EnderPlayer = 3;
export const NetherBed = 4;
export const MovableChest = 5;
export const DragonEgg = 6;

//The Willager
export const BowMaster = 0;
export const StayingHealthy = 1;
export const ArmoredUp = 2;
export const WillagerHat = 3;

//More Food
export const ABigNut = 0;
export const EggsAsPlants = 1;
export const AGoodDiet = 2;
export const WildinFood = 3;
export const GreenHay = 4;
export const CureForTears = 5;
export const LeBaguette = 6;