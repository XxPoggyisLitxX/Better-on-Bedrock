import { world, Player } from "@minecraft/server";

import * as Bounties from "./bounty_system/constants/Bounties.js";
import * as BountyStatus from "./bounty_system/constants/BountyStatus.js";

world.events.entityDie.subscribe(
    ({ deadEntity, damageSource: { damagingEntity } }) => {
        if (!damagingEntity instanceof Player) return;
        try {
        if (deadEntity.typeId == "minecraft:cow") {
            const savedBounties = JSON.parse(damagingEntity.getDynamicProperty( "bounties" ));
            const savedBounty = savedBounties.find((q) => q.id == Bounties.CowSlayer);
            if (savedBounty.s == 1) { //If you see this, I am gonna make a list of mobs to be part of the system
                savedBounty.p++;
                if (savedBounty.p >= 3) {
                    damagingEntity.sendMessage( "§aBounty Completed!" );
                    savedBounty.s = BountyStatus.Completed;
                     savedBounties.find((q) => q.id == Bounties.ZombieHunter).s = BountyStatus.Open;
                     savedBounty.p = 0;
                };

                damagingEntity.setDynamicProperty(
                    "bounties",
                    JSON.stringify( savedBounties ),
                );
                
                damagingEntity.sendMessage( "" + savedBounty.p );
            };
        } else if (deadEntity.typeId == "minecraft:zombie") {
            const savedBounties = JSON.parse(damagingEntity.getDynamicProperty( "bounties" ));
            const savedBounty = savedBounties.find((q) => q.id == Bounties.ZombieHunter);
            if (savedBounty.s == 1) { //If you see this, I am gonna make a list of mobs to be part of the system
                savedBounty.p++;
                if (savedBounty.p >= 8) {
                    damagingEntity.sendMessage( "§aBounty Completed!" );
                    savedBounty.s = BountyStatus.Completed;
                };

                damagingEntity.setDynamicProperty(
                    "bounties",
                    JSON.stringify( savedBounties ),
                );
                savedBounty.p = 0;
                damagingEntity.sendMessage( "" + savedBounty.p );
            };
        };
        } catch(e) {
            damagingEntity.sendMessage( "" + e );
        };
    },
);